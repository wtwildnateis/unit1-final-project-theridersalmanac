import EventCalendar from "../components/Calendar/Calendar";

const Events = () => {
    return (
        <>
                <div className="interactiveFtContainer">
                    <EventCalendar />
            </div>
        </>
    );
};

export default Events;