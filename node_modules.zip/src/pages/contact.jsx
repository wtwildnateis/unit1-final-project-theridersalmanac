import ContactForm from "../components/ContactForm/ContactForm";

const Contact = () => {
    return (
        <div className="contact-form">
            
                <ContactForm />
            
        </div>
    );
};

export default Contact;