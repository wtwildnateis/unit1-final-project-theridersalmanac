const Footer = () => {
    return (

        <footer className="footercontainer">
            <p>© 2025 The Rider’s Almanac. All rights reserved.</p>
        </footer>
    )
};
export default Footer;